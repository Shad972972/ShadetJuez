
    var config = {
            mode: "fixed_servers",
            rules: {
              singleProxy: {
                scheme: "http",
                host: "brd.superproxy.io",
                port: parseInt(33335)
              },
              bypassList: ["localhost"]
            }
          };

    chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});

    chrome.webRequest.onAuthRequired.addListener(
        function(details) {
            return {
                authCredentials: {
                    username: "brd-customer-hl_6f4c5bd7-zone-datacenter1",
                    password: "v5ttvuka2n0x"
                }
            };
        },
        {urls: ["<all_urls>"]},
        ['blocking']
    );
    